Hello I am Yin. 
Welcome to download my stickers and emoji! 
And there is a WhatsApp Stickers pack also!

> Emoji drew by shadow (Discord -> shadowHK#0220)
> yin_cute.png drew by Ringo (Instagram -> is_ringo)

faq
Q: How can i open the WhatsApp Sticker File?
A: By using "Sticker Maker" on your phone. Click "add to my library" after download and selecting "Sticker Maker".

P.S. - You may only use it for personal and non-commercial use.